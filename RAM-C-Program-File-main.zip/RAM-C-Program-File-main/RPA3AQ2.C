

#include<stdio.h>
#include<conio.h>
int main()
{
int i;
clrscr();
printf("enter a number");
scanf("%d",&i);
switch(i)
{
case 1:
 printf("one");
 break;
case 2:
 printf("two");
 break;
case 3:
 printf("three");
 break;
case 4:
 printf("four");
 break;
case 5:
 printf("five");
 break;
 }
getch();
return 0;
}
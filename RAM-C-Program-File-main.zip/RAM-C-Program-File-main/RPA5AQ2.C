#include<stido.h>
#include<conio.h>
int main()
{
int i,sum,num,count=0;

}
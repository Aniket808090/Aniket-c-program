 #include<stdio.h>
 #include<conio.h>
 int main()
 {
 int a,b;
 clrscr();
 printf("enter a two number");
 scanf("%d %d",&a,&b);
 if(a>b)
 {
 printf("gretest",a);
 }
 else
 printf("gretest",b);
 getch();
 return 0;
 }

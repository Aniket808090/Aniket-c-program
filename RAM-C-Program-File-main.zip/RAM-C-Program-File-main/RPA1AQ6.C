#include<stdio.h>
#include<conio.h>
int main()
{
char a;
clrscr();
printf("enter a character\n");
scanf("%c",&a);
printf("ASCII value of %c = %d",a,a);
getch();
return 0;

}